# tailword

A WordPress theme made using tailwind


## usage

- dev

	```sh
	npm run watch
	```

- prod 

	the npm run production command is launched in the GitHub workflow